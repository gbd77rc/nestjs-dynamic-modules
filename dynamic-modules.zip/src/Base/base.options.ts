export declare type BaseOptions = {
    name: string;
}